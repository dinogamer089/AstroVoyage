package com.example.astrovoyage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class login_screen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);

        EditText username =(EditText) findViewById(R.id.username_bar);
        EditText password =(EditText) findViewById(R.id.password_bar);

        Button loginbtn =(Button) findViewById(R.id.slbtn);

        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(username.getText().toString().equals("dinogamer089") && password.getText().toString().equals("AstroVoyager"))
                {
                    try {
                        Toast.makeText(login_screen.this, "Login Succesful!", Toast.LENGTH_SHORT).show();
                        Thread.sleep(1500);
                        startActivity(new Intent(login_screen.this, solar_system.class));
                    }catch(InterruptedException e){
                        System.out.println("got interrupted!");
                    }
                }else{
                    Toast.makeText(login_screen.this, "Login Unsuccesful!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}