package com.example.astrovoyage;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity
{
    TextView a;
    Spinner spida,spidasp,spidad;
    Button botida,bvuelta;
    private int dia, mes, anio;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        a=(TextView)findViewById(R.id.usuario);
        spida=(Spinner)findViewById(R.id.spinnerida);
        spidasp=(Spinner)findViewById(R.id.spinnerpoint);
        spidad=(Spinner)findViewById(R.id.spinnerdestination);
        botida=(Button)findViewById(R.id.buttonida);
        bvuelta=(Button)findViewById(R.id.buttonvuelta);

        String[]opc={"1 Adult","2 Adults","3 Adults","4 Adults","5 Adults"};
        String[]opcpoint={"Earth","Mars","Mercury","Venus","Saturn","Uranus","Neptune"};

        ArrayAdapter <String> adapter=new ArrayAdapter<String>(this, R.layout.spinner_item_vuelos, opc);
        spida.setAdapter(adapter);
        ArrayAdapter <String> adapter1=new ArrayAdapter<String>(this, R.layout.spinner_item_vuelos, opcpoint);
        spidasp.setAdapter(adapter1);
        ArrayAdapter <String> adapter2=new ArrayAdapter<String>(this, R.layout.spinner_item_vuelos, opcpoint);
        spidad.setAdapter(adapter2);
    }
    public void SinTexto(View view)
    {
        a.setText("");
    }

    public void bida(View view)
    {
        final Calendar c=Calendar.getInstance();
        dia=c.get(Calendar.DAY_OF_MONTH);
        mes=c.get(Calendar.MONTH);
        anio=c.get(Calendar.YEAR);

        DatePickerDialog datePickerDialog=new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth)
            {
                String fecha=dayOfMonth+"/"+monthOfYear+"/"+year;
                botida.setText(fecha);
            }
        },2023, mes, dia);
        datePickerDialog.show();
    }

    public void bvuelta(View view)
    {
        final Calendar c=Calendar.getInstance();
        dia=c.get(Calendar.DAY_OF_MONTH);
        mes=c.get(Calendar.MONTH);
        anio=c.get(Calendar.YEAR);

        DatePickerDialog datePickerDialog=new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int monthOfYear, int dayOfMonth)
            {
                String fecha=dayOfMonth+"/"+monthOfYear+"/"+year;
                bvuelta.setText(fecha);
            }
        },2023, mes, dia);
        datePickerDialog.show();
    }

    public void menu(View view)
    {
        Intent m=new Intent(this, Menu.class);
        startActivity(m);
    }
}